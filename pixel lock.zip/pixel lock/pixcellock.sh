#!/bin/bash

# File and Folder Lock/Unlock Script

# File paths
PASSWORD_FILE="./password.txt"
TARGET_INFO="./target_info.txt"
LOG_FILE="./activity_log.txt"

# Function to log activities
log_activity() {
    echo "$(date): $1" >> "$LOG_FILE"
}

# Check for dependencies
check_dependencies() {
    if ! command -v zenity &>/dev/null || ! command -v zip &>/dev/null || ! command -v xdg-open &>/dev/null; then
        zenity --error --text="Required dependencies missing. Please install: zenity, zip, xdg-open."
        exit 1
    fi
}

# Set a password
set_password() {
    password=$(zenity --password --title="Set Password" --width=500 --height=200)
    if [ -z "$password" ]; then
        zenity --error --text="Password cannot be empty!" --width=400 --height=150
        return
    fi
    echo "$password" > "$PASSWORD_FILE"
    zenity --info --text="Password has been set successfully!" --width=400 --height=150
    log_activity "Password set successfully."
}

# Select a file or folder to lock
select_target() {
    target=$(zenity --file-selection --title="Select File or Folder to Lock" --width=500 --height=300)
    if [ -z "$target" ]; then
        zenity --error --text="No file or folder selected!" --width=400 --height=150
        return
    fi
    echo "$target" > "$TARGET_INFO"
    zenity --info --text="Target selected: $target" --width=400 --height=150
    log_activity "Target selected: $target"
}

# Lock the selected file or folder
lock_target() {
    if [ ! -f "$PASSWORD_FILE" ]; then
        zenity --error --text="No password set! Please set a password first." --width=400 --height=150
        return
    fi

    if [ ! -f "$TARGET_INFO" ]; then
        zenity --error --text="No target selected! Please select a target first." --width=400 --height=150
        return
    fi

    password=$(cat "$PASSWORD_FILE")
    target=$(cat "$TARGET_INFO")
    target_name=$(basename "$target")
    zip_file="${target_name}.locked.zip"

    if [ -f "$zip_file" ]; then
        zenity --error --text="The target is already locked!" --width=400 --height=150
        return
    fi

    zip -r -P "$password" "$zip_file" "$target" && rm -rf "$target"
    zenity --info --text="Target locked successfully as $zip_file." --width=400 --height=150
    log_activity "Target locked: $zip_file"
}

# Unlock the selected file or folder
unlock_target() {
    if [ ! -f "$PASSWORD_FILE" ]; then
        zenity --error --text="No password set! Please set a password first." --width=400 --height=150
        return
    fi

    if [ ! -f "$TARGET_INFO" ]; then
        zenity --error --text="No target information available. Please lock a target first." --width=400 --height=150
        return
    fi

    password=$(cat "$PASSWORD_FILE")
    target=$(cat "$TARGET_INFO")
    target_name=$(basename "$target")
    zip_file="${target_name}.locked.zip"

    if [ ! -f "$zip_file" ]; then
        zenity --error --text="Locked file not found! Ensure the correct locked file exists." --width=600 --height=300
        return
    fi

    entered_password=$(zenity --password --title="Enter Password to Unlock" --width=600 --height=300)
    if [ "$entered_password" != "$password" ]; then
        zenity --error --text="Incorrect password!" --width=600 --height=300
        log_activity "Failed unlock attempt for: $zip_file"
        return
    fi

    unzip -P "$password" "$zip_file" && rm -f "$zip_file"
    zenity --info --text="Target unlocked successfully!" --width=600 --height=300
    log_activity "Target unlocked: $target_name"
    xdg-open "$target"
}

# Reset the setup
reset_setup() {
    rm -f "$PASSWORD_FILE" "$TARGET_INFO" *.locked.zip
    zenity --info --text="All settings have been reset." --width=600 --height=300
    log_activity "Setup reset."
}

# Main menu
main_menu() {
    action=$(zenity --list --radiolist --title="File and Folder Lock/Unlock Menu" \
        --column="Select" --column="Action" \
        TRUE "Set Password" \
        FALSE "Select Target" \
        FALSE "Lock Target" \
        FALSE "Unlock Target" \
        FALSE "Reset Setup" \
        --height=1200 --width=800)

    case $action in
    "Set Password")
        set_password
        ;;
    "Select Target")
        select_target
        ;;
    "Lock Target")
        lock_target
        ;;
    "Unlock Target")
        unlock_target
        ;;
    "Reset Setup")
        reset_setup
        ;;
    *)
        zenity --error --text="No action selected!" --width=600 --height=300
        ;;
    esac
}

# Run the script
check_dependencies
main_menu

